package com.example.ThirdYearProject;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.ContentView;
import androidx.annotation.Nullable;

public class BroadcastScreen extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_broadcast_screen);
    }

    public void final_create_broadcast(View view) {
        Intent FinalBroadcast = new Intent(this, HomeScreen.class);
        finish();
        startActivity(FinalBroadcast);

    }

}
