package com.example.ThirdYearProject;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;

public class DateScreen extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.datescreen);
        String ChosenDate =  null;
        if (savedInstanceState == null) {
            Bundle extras = getIntent().getExtras();
            if (extras == null) {
                finish();
            } else {
                ChosenDate = extras.getString("stringDate");
            }
        } else {
            ChosenDate = (String) savedInstanceState.getSerializable("stringDate");
        }
        TextView UsersCreden = findViewById(R.id.ChoseDates);
        UsersCreden.append(" " + ChosenDate);
    }

    public void GobackScreen(View view) {
        Intent GoToCalendarScreen = new Intent(this, CalendarScreen.class);
        startActivity(GoToCalendarScreen);
        finish();
    }
}
