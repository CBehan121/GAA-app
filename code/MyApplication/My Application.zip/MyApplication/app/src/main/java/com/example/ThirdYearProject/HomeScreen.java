package com.example.ThirdYearProject;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;

public class HomeScreen extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.homescreen);
        String userCreds =  null;
        if (savedInstanceState == null) {
            Bundle extras = getIntent().getExtras();
            if (extras == null) {
                finish();
            } else {
                userCreds = extras.getString("clubName");
            }
        } else {
            userCreds = (String) savedInstanceState.getSerializable("clubName");
        }

        TextView UsersCreden = findViewById(R.id.the_users_cred);
        UsersCreden.append(" " + userCreds);

    }

    public void Logout_user(View view) {
        Intent Logout  =  new Intent(this, LoginScreen.class);
        startActivity(Logout);
        finish();
    }


    public void create_broadcast(View view) {
        Intent CreateBroadcast = new Intent(this, BroadcastScreen.class);
        startActivity(CreateBroadcast);

    }
    public void OpenCalendar(View view) {
        Intent opencalendar = new Intent(this, CalendarScreen.class);
        startActivity(opencalendar);

    }

    public void MoveToClubListScreen(View view) {
        Intent clubSearch = new Intent(this, ClubSearchScreen.class);
        startActivity(clubSearch);
    }
}
