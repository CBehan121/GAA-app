package com.example.ThirdYearProject;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.annotation.Nullable;

public class LoginScreen extends AppCompatActivity{
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.loginscreen);
    }


    public void OnSendUsersName(View view) {
        Intent sendUserCreds = new Intent(this, HomeScreen.class);
        EditText clubNameET =  (EditText) findViewById(R.id.user_name_editable);
        String clubName = String.valueOf(clubNameET.getText());
        sendUserCreds.putExtra("clubName",clubName);
        startActivity(sendUserCreds);
        finish();}

    public void RegisterNewUser(View view) {
        Intent createNewUser = new Intent(this, RegistrationScreen.class);
        startActivity(createNewUser);

    }

    public void ForgotPassword(View view) {
        Intent forgotPassword =  new Intent(this, ForgotPassword.class);
        startActivity(forgotPassword);
    }
}
