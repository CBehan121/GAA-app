package com.example.ThirdYearProject;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.ContentView;
import androidx.annotation.Nullable;

public class OpposingTeamsHP extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.opposing_team_hp);
    }

    public void create_Challenge(View view) {
        Intent ChallengeUser = new Intent(this, ChallengeRequestScreen.class );
        startActivity(ChallengeUser);
    }
}
