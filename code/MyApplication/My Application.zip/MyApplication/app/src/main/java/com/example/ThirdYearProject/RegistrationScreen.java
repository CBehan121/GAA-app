package com.example.ThirdYearProject;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class RegistrationScreen extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registrationscreen);
    }


    public void CompleteReg(View view) {
        EditText clubName = findViewById(R.id.clubname);
        EditText email = findViewById(R.id.emailText);
        String emailText = String.valueOf(email.getText());
        String ClubNameText = String.valueOf(clubName.getText());
        EditText password1 = findViewById(R.id.password1);
        EditText password2 = findViewById(R.id.password2);
        String password1String = String.valueOf(password1.getText());
        String password2String = String.valueOf(password2.getText());
        Context context = getApplicationContext();
        int duration = Toast.LENGTH_SHORT;
        if (password1String.equals(password2String) && !emailText.isEmpty() && !ClubNameText.isEmpty()) {
            Intent Completeregistration = new Intent(this, LoginScreen.class);
            startActivity(Completeregistration);
            CharSequence text = "Registering...";
            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
            finish();
        }
        else if(!password1String.equals(password2String)){
            CharSequence text = "Passwords dont match";
            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        }
        else{
            CharSequence text = "Please fill in all fields ";
            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        }

    }
}
